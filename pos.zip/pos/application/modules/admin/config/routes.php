<?php 
$route["admin"] = "dashboard";