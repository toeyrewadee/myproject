<div class="page-prefooter">
	<div class="container">
		<div class="row">
			<!--<div class="col-md-3 col-sm-6 col-xs-12 footer-block">
				<h2>About</h2>
				<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam dolore. </p>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12 footer-block">
				<h2>Subscribe Email</h2>
				<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam dolore. </p>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12 footer-block">
				<h2>Follow Us On</h2>
				<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam dolore. </p>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12 footer-block">
				<h2>Contacts</h2>
				<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam dolore. </p>
			</div>-->
		</div>
	</div>
</div>

<div class="page-footer">
	<div class="container">
		2016 CHMSC-Talisay.
	</div>
</div>