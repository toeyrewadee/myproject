<?php

class User extends AdminController{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		
	}
}