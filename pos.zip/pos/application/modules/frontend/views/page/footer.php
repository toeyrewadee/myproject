<div class="footer">
</div>
<div class="copy-right">
	<div class="container">
		<p>© 2016 Carlos Hilado Memorial State College Techno Bazaar . All rights reserved</p>
	</div>
</div>