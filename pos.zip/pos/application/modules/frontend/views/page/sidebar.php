<div class="sidebar col-md-3 col-sm-3">
	<ul class="list-group margin-bottom-25 sidebar-menu">
		<li class="list-group-item clearfix">
			<a href="<?php echo site_url("customer/account"); ?>">Account</a>
		</li>
		<li class="list-group-item clearfix">
			<a href="<?php echo site_url("customer/reservation") ?>">Reservation</a>
		</li>
		<li class="list-group-item clearfix">
			<a href="<?php echo site_url("customer/order") ?>">Orders</a>
		</li>
	</ul>
</div>